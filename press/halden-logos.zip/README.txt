Wordmark set in Cinzel (SIL Open Font License).
The chevron emblem is 128 px; a larger master is coming.
